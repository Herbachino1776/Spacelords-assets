# Sprite Generation Report

- player MantidPrime frames 24
- player Scarabos frames 24
- enemy_small Celestis frames 18
- enemy_small Stardust frames 18
- enemy_large OrionLord frames 24
- npc Oracle frames 10
- npc LarvalKid frames 10
- weapons StingerBlade frames 12
- weapons CosmicStaff frames 12
- items CosmicLoot frames 16
- ui digits_sheet.png copied
- ui mp_bar.png copied
- ui hp_bar.png copied
